-- begin BPROC_USER_GROUP
create table BPROC_USER_GROUP (
    ID uniqueidentifier,
    VERSION integer not null,
    CREATE_TS datetime2,
    CREATED_BY varchar(50),
    UPDATE_TS datetime2,
    UPDATED_BY varchar(50),
    DELETE_TS datetime2,
    DELETED_BY varchar(50),
    --
    NAME varchar(255) not null,
    CODE varchar(255) not null,
    DESCRIPTION varchar(max),
    TYPE_ varchar(50) not null,
    --
    primary key nonclustered (ID)
)^
-- end BPROC_USER_GROUP
-- begin BPROC_USER_GROUP_ROLE_LINK
create table BPROC_USER_GROUP_ROLE_LINK (
    USER_GROUP_ID uniqueidentifier,
    ROLE_ID uniqueidentifier,
    primary key (USER_GROUP_ID, ROLE_ID)
)^
-- end BPROC_USER_GROUP_ROLE_LINK
-- begin BPROC_USER_GROUP_USER_LINK
create table BPROC_USER_GROUP_USER_LINK (
    USER_GROUP_ID uniqueidentifier,
    USER_ID uniqueidentifier,
    primary key (USER_GROUP_ID, USER_ID)
)^
-- end BPROC_USER_GROUP_USER_LINK
-- begin BPROC_CONTENT_STORAGE
create table BPROC_CONTENT_STORAGE (
    ID uniqueidentifier,
    VERSION integer not null,
    CREATE_TS datetime2,
    CREATED_BY varchar(50),
    UPDATE_TS datetime2,
    UPDATED_BY varchar(50),
    DELETE_TS datetime2,
    DELETED_BY varchar(50),
    --
    NAME varchar(1000) not null,
    CONTENT image,
    TYPE_ varchar(255),
    AUTHOR_ID uniqueidentifier,
    --
    primary key nonclustered (ID)
)^
-- end BPROC_CONTENT_STORAGE
